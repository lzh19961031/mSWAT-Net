
from .xception import *


__all__ = ['build_backbone']


def build_backbone(cfgs, backbone, output_stride, BatchNorm, pretrained=True):
    if backbone == 'resnet':
        return ResNet101(output_stride, BatchNorm, pretrained=pretrained)
    elif backbone == 'xception':
        return AlignedXception(output_stride, BatchNorm, pretrained=pretrained)
    elif backbone == 'drn':
        return drn_d_54(BatchNorm, pretrained=pretrained)
    elif backbone == 'mobilenet':
        return MobileNetV2(output_stride, BatchNorm, pretrained=pretrained)
    elif backbone == 'resnet_bcl':
        return ResNet101_bcl(output_stride, BatchNorm, pretrained=pretrained)
    elif backbone == 'xception_bcl':
        return AlignedXception_bcl(output_stride, BatchNorm, pretrained=pretrained)
    elif backbone == 'resnet_scl':
        return ResNet101_scl(cfgs, output_stride, BatchNorm, pretrained=pretrained)
    else:
        raise NotImplementedError
