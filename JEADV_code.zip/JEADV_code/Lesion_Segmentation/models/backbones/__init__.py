

from .xception import *




__all__ = ['build_backbone']


def build_backbone(cfgs, backbone, output_stride, BatchNorm, pretrained=True):
    return AlignedXception(output_stride, BatchNorm, pretrained=pretrained)

