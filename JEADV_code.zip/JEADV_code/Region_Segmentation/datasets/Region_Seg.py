import os
import glob
import copy
import numpy as np
import PIL.Image as Image
import torch
from torch.utils.data import Dataset
import torch.nn as nn

try:
    import sys
    import mc
    sys.path.append('/mnt/lustre/share/pymc/py3/')
except:
    print('memcache not exist!')


__all__ = ['Region_Seg']

class Region_Seg(Dataset):
    def __init__(self, cfgs, mode='train'):
        if mode == 'train':
            sub_dir = 'train'
        else:
            sub_dir = 'val'

        self.cfgs = cfgs
        self.mode = mode
        self.imgs = make_dataset(cfgs, cfgs.dataset.root_path  + '/' + sub_dir)

    def __getitem__(self, index):

        img_path, mask_path = self.imgs[index]
        img = Image.open(img_path).convert('RGB')
        mask = np.load(mask_path)
        mask = Image.fromarray(mask)
 
        img = img.resize((self.cfgs.dataset.input_size[0], self.cfgs.dataset.input_size[1]), Image.NEAREST)
        mask = mask.resize((self.cfgs.dataset.input_size[0], self.cfgs.dataset.input_size[1]), Image.NEAREST)

        img, mask = np.array(img), np.array(mask)
        img, mask = img.copy(), mask.copy()

        mask = np.expand_dims(mask, 0)
        mask = np.around(mask)

        return img, mask, img_path


    def __len__(self):
        return len(self.imgs)


def make_dataset(cfgs, root):
    input_collection = []
    img_types = ['.jpg', '.jpeg', '.png', '.JPG']
    img_paths, mask_paths = [], []
    for img_type in img_types:
        img_paths.extend(sorted(glob.glob(root + '/img/*' + img_type)))
        mask_paths.extend(sorted(glob.glob(root + '/mask_png/*')))


    for img_path in img_paths:
        mask_path = img_path.split('/')[0] + '/' + img_path.split('/')[1] + '/' + '/mask_npy/' + img_path.split('/')[-1][:-4] + '.npy'
        input_collection.append((img_path, mask_path))

    return input_collection


