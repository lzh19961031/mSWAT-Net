import subprocess


def run():
    cmd = 'python3 -m torch.distributed.launch train.py --local_rank {} --config {}'\
    .format(-1, 'configs/config.yaml')
    p = subprocess.Popen(cmd, shell=True)
    p.communicate()


if __name__ == '__main__':
    run()