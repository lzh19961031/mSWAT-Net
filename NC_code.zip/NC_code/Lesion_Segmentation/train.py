import argparse
import os
import pickle
import yaml
import shutil
import time
import math
import glob
import re
import numpy as np
import datasets
import models
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel
from utils.LARC import LARC
from addict import Dict
from utils import helper_utils, loss_utils, schd_utils, dist_utils
torch.autograd.set_detect_anomaly(True)
import os
os.environ['CUDA_LAUNCH_BLOCKING'] = "1"


def parse_args():
    parser = argparse.ArgumentParser(description='PyTorch Implementation of Amoeba')
    parser.add_argument('--config', default='configs/tem.yaml',
                        type=str, help='path to config file')
    parser.add_argument('--save_path', default='./runs/', type=str, help='path to save checkpoint')
    parser.add_argument('--resume_from', default=None, type=str, help='path to checkpoint')
    parser.add_argument("--port", default='23333') 
    parser.add_argument("--local_rank", default=None)   
    return parser.parse_args()


def main(args):
    cfgs = yaml.load(open(args.config, 'r'), Loader=yaml.Loader)
    cfgs = Dict(cfgs)

    dist_utils.init_distributed_mode(args)
    dist_utils.init_seeds(seed=cfgs.seed, cuda_deterministic=False)

    args.device = 'cuda' if torch.cuda.is_available() else 'cpu'

    train_dataset = datasets.__dict__[cfgs.dataset.mode](cfgs, mode='train')
    train_sampler = torch.utils.data.distributed.DistributedSampler(train_dataset, num_replicas=args.world_size, rank=args.rank)
    train_loader = torch.utils.data.DataLoader(train_dataset,
                                               sampler=train_sampler,
                                               batch_size=cfgs.batch_size,
                                               num_workers=cfgs.num_workers,
                                               drop_last=True,
                                               pin_memory=True)

    cfgs.train_len = len(train_dataset)

    model = models.__dict__[cfgs.model.mode](args, cfgs)
    model = nn.SyncBatchNorm.convert_sync_batchnorm(model)
    model.to(args.device)
    model = DistributedDataParallel(model, device_ids=[args.local_rank], find_unused_parameters=True)
    
    if cfgs.optm.mode == 'adam':
        base_lr = cfgs.optm.adam.base_lr
        final_lr = cfgs.optm.adam.final_lr
        wd = cfgs.optm.adam.wd
        optimizer = torch.optim.Adam(
            model.parameters(),
            lr=base_lr,
            weight_decay=wd)


    lr_scheduler = schd_utils.get_scheduler(cfgs, train_loader)
    criterion = loss_utils.get_criterion(args, cfgs)

    start_epoch = 0
    rank_metric = {}
    for metric_name in cfgs.val.rank_metric:
        rank_metric[metric_name] = 0

    for epoch in range(start_epoch, cfgs.epochs):
        train_loader.sampler.set_epoch(epoch)
        train(args, cfgs, train_loader, model, criterion, optimizer, lr_scheduler, epoch)
        if args.rank == 0 and epoch % cfgs.save_checkpoint == 0:
            path = os.path.join('epoch_' + str(epoch) + '.pth')
            save_dict = {
                "epoch": epoch,
                "state_dict": model.state_dict(),
                "optimizer": optimizer.state_dict(),
            }
            torch.save(save_dict, path)  



def train(args, cfgs, train_loader, model, criterion, optimizer, lr_scheduler, epoch):

    batch_time = helper_utils.AverageMeter()
    data_time = helper_utils.AverageMeter()
    losses = helper_utils.AverageMeter()

    model.train()

    end = time.time()
    for it, (img, gt_mask, img_path) in enumerate(train_loader):
        data_time.update(time.time() - end)
        img = img.float().to(args.device).permute(0, 3, 1, 2).contiguous()  # size: (N, C, d1, d2)
        gt_mask = gt_mask.long().to(args.device)
        
        pred = model(img)
        loss = criterion.forward(pred, gt_mask)
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        iteration = epoch * len(train_loader) + it
        lr_scheduler.it_step(optimizer, iteration)

        losses.update(loss.item(), gt_mask[0].size(0))
        batch_time.update(time.time() - end)
        end = time.time()




if __name__ == '__main__':
    args = parse_args()
    main(args)
