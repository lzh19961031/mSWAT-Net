import torch
import torch.nn as nn
import sys
import numpy as np
sys.path.append('../')
from torch.autograd import Variable


class get_criterion(nn.Module):

    def __init__(self, args, cfgs):
        self.args = args
        self.cfgs = cfgs
        self.criterion_collection = []
        self.device = self.args.device
        
        for criterion_name, criterion_weight in cfgs.criterions:
            if criterion_name == 'ce':
                criterion = nn.CrossEntropyLoss()
            self.criterion_collection.append((criterion, criterion_weight, criterion_name))

    def forward(self, pred, gt):
        final_loss = 0

        if type(pred) == tuple or type(pred) == list:
            output = pred[0]
        else:
            output = pred

        for item in self.criterion_collection:       
            criterion, criterion_weight, loss_name = item

            if loss_name == 'ce':
                gt = gt.squeeze(1) 
                cur_loss = criterion_weight * criterion(output, gt)  
                final_loss += cur_loss       
            
        return final_loss

