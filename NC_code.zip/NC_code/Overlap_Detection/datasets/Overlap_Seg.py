import os
import glob
import copy
import numpy as np
import PIL.Image as Image
import torch
from torch.utils.data import Dataset
import torch.nn as nn
import pandas as pd
import math

try:
    import sys
    import mc
    sys.path.append('/mnt/lustre/share/pymc/py3/')
except:
    print('memcache not exist!')


__all__ = ['Overlap_Seg']


class Overlap_Seg(Dataset):
    def __init__(self, cfgs, mode='train'):
        if mode == 'train':
            sub_dir = 'train'
        else:
            sub_dir = 'val'

        self.cfgs = cfgs
        self.mode = mode
        self.splitnumber = cfgs.dataset.splitnumber 
        self.fold_all_number = cfgs.dataset.fold_all_number
        self.imgs = make_dataset(cfgs, cfgs.dataset.root_path, self.splitnumber, self.mode, self.fold_all_number)


    def __getitem__(self, index):
        img_list = []

        img_path0, mask_path0, img_path1, mask_path1 = self.imgs[index]

        img0 = Image.open(img_path0).convert('RGB')
        mask0 = Image.open(mask_path0).convert('L')
        img0 = img0.resize((self.cfgs.dataset.input_size[0], self.cfgs.dataset.input_size[1]), resample=3)

        img1 = Image.open(img_path1).convert('RGB')
        mask1 = Image.open(mask_path1).convert('L')
        img1 = img1.resize((self.cfgs.dataset.input_size[0], self.cfgs.dataset.input_size[1]), resample=3)


        if self.mode == 'train':
            mask0 = mask0.resize((self.cfgs.dataset.input_size[0], self.cfgs.dataset.input_size[1]), resample=3)
            mask1 = mask1.resize((self.cfgs.dataset.input_size[0], self.cfgs.dataset.input_size[1]), resample=3)

        img0, mask0 = np.array(img0), np.array(mask0)
        img0, mask0 = img0.copy(), mask0.copy()
        mask0[mask0 > 0] = 1
        img1, mask1 = np.array(img1), np.array(mask1)
        img1, mask1 = img1.copy(), mask1.copy()
        mask1[mask1 > 0] = 1
        mask0 = np.expand_dims(mask0, 0)
        mask1 = np.expand_dims(mask1, 0)

        return img0, mask0, img_path0, img1, mask1, img_path1


    def __len__(self):
        return len(self.imgs)


def find_view(index1, index2, string_list):
    result = []
    for string in string_list:
        if '-0.png' in string and index1 in string and index2 in string:
            result.append(string)

    return result


def make_dataset(cfgs, root_path, splitnumber, mode, fold_all_number):
    input_collection = []

    csv_name = root_path + '/split_' + str(splitnumber) + '.csv'
    df = pd.read_csv(csv_name) 
    df.columns=["A","B"]
    if mode == 'train':
        img = df["A"]
        img = np.array(img)
    elif mode == 'val':
        img = df["B"] 
        img = np.array(img) 
        img = img[~np.isnan(img)] 

    for i in range(0, (len(img))):
        all_list = os.listdir(root_path + '/' + str(int(img[i])))
        img_path_list = find_view('before', 'left', all_list) #
        img_path_list.sort()
        img_path0 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[0]
        img_mask_path0 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[0].split('.')[0][:-1] + '1_mask.png'
        img_path1 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[4]
        img_mask_path1 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[4].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path0, img_mask_path0, img_path1, img_mask_path1))
        img_path2 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[1]
        img_mask_path2 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[1].split('.')[0][:-1] + '1_mask.png'
        img_path3 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[5]
        img_mask_path3 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[5].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path2, img_mask_path2, img_path3, img_mask_path3))
        img_path4 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[2]
        img_mask_path4 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[2].split('.')[0][:-1] + '1_mask.png'
        img_path5 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[6]
        img_mask_path5 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[6].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path4, img_mask_path4, img_path5, img_mask_path5))     
        img_path6 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[3]
        img_mask_path6 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[3].split('.')[0][:-1] + '1_mask.png'
        img_path7 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[7]
        img_mask_path7 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[7].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path6, img_mask_path6, img_path7, img_mask_path7))
        img_path_list = find_view('before', 'right', all_list) #
        img_path_list.sort()
        img_path0 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[0]
        img_mask_path0 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[0].split('.')[0][:-1] + '1_mask.png'
        img_path1 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[4]
        img_mask_path1 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[4].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path0, img_mask_path0, img_path1, img_mask_path1))

        img_path2 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[1]
        img_mask_path2 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[1].split('.')[0][:-1] + '1_mask.png'
        img_path3 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[5]
        img_mask_path3 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[5].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path2, img_mask_path2, img_path3, img_mask_path3))
        img_path4 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[2]
        img_mask_path4 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[2].split('.')[0][:-1] + '1_mask.png'
        img_path5 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[6]
        img_mask_path5 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[6].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path4, img_mask_path4, img_path5, img_mask_path5))   
        img_path6 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[3]
        img_mask_path6 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[3].split('.')[0][:-1] + '1_mask.png'
        img_path7 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[7]
        img_mask_path7 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[7].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path6, img_mask_path6, img_path7, img_mask_path7))
        img_path_list = find_view('behind', 'left', all_list) #
        img_path_list.sort()
 
        img_path0 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[0]
        img_mask_path0 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[0].split('.')[0][:-1] + '1_mask.png'
        img_path1 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[4]
        img_mask_path1 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[4].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path0, img_mask_path0, img_path1, img_mask_path1))

        img_path2 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[1]
        img_mask_path2 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[1].split('.')[0][:-1] + '1_mask.png'
        img_path3 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[5]
        img_mask_path3 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[5].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path2, img_mask_path2, img_path3, img_mask_path3))
        img_path4 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[2]
        img_mask_path4 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[2].split('.')[0][:-1] + '1_mask.png'
        img_path5 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[6]
        img_mask_path5 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[6].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path4, img_mask_path4, img_path5, img_mask_path5))    
        img_path6 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[3]
        img_mask_path6 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[3].split('.')[0][:-1] + '1_mask.png'
        img_path7 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[7]
        img_mask_path7 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[7].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path6, img_mask_path6, img_path7, img_mask_path7))

        img_path_list = find_view('behind', 'right', all_list) #
        img_path_list.sort()
        img_path0 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[0]
        img_mask_path0 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[0].split('.')[0][:-1] + '1_mask.png'
        img_path1 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[4]
        img_mask_path1 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[4].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path0, img_mask_path0, img_path1, img_mask_path1))
        img_path2 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[1]
        img_mask_path2 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[1].split('.')[0][:-1] + '1_mask.png'
        img_path3 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[5]
        img_mask_path3 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[5].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path2, img_mask_path2, img_path3, img_mask_path3))
        img_path4 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[2]
        img_mask_path4 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[2].split('.')[0][:-1] + '1_mask.png'
        img_path5 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[6]
        img_mask_path5 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[6].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path4, img_mask_path4, img_path5, img_mask_path5))
     
        img_path6 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[3]
        img_mask_path6 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[3].split('.')[0][:-1] + '1_mask.png'
        img_path7 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[7]
        img_mask_path7 = root_path + '/' + str(int(img[i])) + '/' + img_path_list[7].split('.')[0][:-1] + '1_mask.png'
        input_collection.append((img_path6, img_mask_path6, img_path7, img_mask_path7))
       
    return input_collection