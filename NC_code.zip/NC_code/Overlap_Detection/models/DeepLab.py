import yaml
import torch
import torch.nn as nn
import torch.nn.functional as F
from addict import Dict
from .necks.aspp import build_aspp
from .decoders.decoder import build_decoder
from .backbones import build_backbone


__all__ = ['DeepLab']


class DeepLab(nn.Module):
    def __init__(self, args, cfgs):
        super(DeepLab, self).__init__()

        backbone = cfgs.model.backbone
        output_stride = cfgs.model.output_stride
        freeze_bn = cfgs.model.freeze_bn
        num_classes = cfgs.model.num_classes

        if backbone == 'drn':
            output_stride = 8

        BatchNorm = nn.BatchNorm2d

        try: 
            pretrained = cfgs.model.pretrained_backbone
        except:
            pretrained = True

        self.backbone = build_backbone(cfgs, backbone, output_stride, BatchNorm, pretrained=pretrained)
        self.aspp = build_aspp(backbone, output_stride, BatchNorm)
        self.decoder = build_decoder(num_classes, backbone, BatchNorm)
        self.freeze_bn = freeze_bn

        self.conv1 = nn.Conv2d(num_classes*2, num_classes, kernel_size=3,padding=1)
        self.conv2 = nn.Conv2d(num_classes*2, num_classes, kernel_size=3,padding=1)

    def forward(self, input1, input2):
        x1, low_level_feat1 = self.backbone(input1)
        x1 = self.aspp(x1)
        x1 = self.decoder(x1, low_level_feat1)

        x2, low_level_feat2 = self.backbone(input2)
        x2 = self.aspp(x2)
        x2 = self.decoder(x2, low_level_feat2)

        x = torch.cat([x1, x2], dim=1)
        x1_result = F.interpolate(self.conv1(x), size=input1.size()[2:], mode='bilinear', align_corners=True)
        x2_result = F.interpolate(self.conv2(x), size=input2.size()[2:], mode='bilinear', align_corners=True)
        return x1_result, x2_result

    def apply_freeze_bn(self):
        for m in self.modules():
            if isinstance(m, nn.BatchNorm2d):
                m.eval()

    def get_1x_lr_params(self):
        modules = [self.backbone]
        for i in range(len(modules)):
            for m in modules[i].named_modules():
                if self.freeze_bn:
                    if isinstance(m[1], nn.Conv2d):
                        for p in m[1].parameters():
                            if p.requires_grad:
                                yield p
                else:
                    if isinstance(m[1], nn.Conv2d) or isinstance(m[1], nn.BatchNorm2d):
                        for p in m[1].parameters():
                            if p.requires_grad:
                                yield p

    def get_10x_lr_params(self):
        modules = [self.aspp, self.decoder]
        for i in range(len(modules)):
            for m in modules[i].named_modules():
                if self.freeze_bn:
                    if isinstance(m[1], nn.Conv2d):
                        for p in m[1].parameters():
                            if p.requires_grad:
                                yield p
                else:
                    if isinstance(m[1], nn.Conv2d) or isinstance(m[1], nn.BatchNorm2d):
                        for p in m[1].parameters():
                            if p.requires_grad:
                                yield p


